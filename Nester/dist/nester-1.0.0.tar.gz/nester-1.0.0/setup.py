from distutils.core import setup

setup(
name = 'nester',
version = '1.0.0',
py_modules = ['nester'],
author = 'ShadowofZeus',
author_email = 'ShadowofZeus@headfirstlabs.com',
url = 'http://www.headfirstlabs.com',
description = 'A simple printer of nested lists',
)
